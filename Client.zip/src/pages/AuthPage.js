import React from "react";
import '../index.css';

export const AuthPage = () => {
    return (
        <div className="container">
            <h1> Auth Page</h1>
        </div>
    )
}