import React from "react";

export const CreatePage = () => {
    return (
        <div>
            <h1>Create Page</h1>
        </div>
    )
}