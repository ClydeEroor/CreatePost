import React from "react";

export const LinksPage = () => {
    return (
        <div>
            <h1>Links Page</h1>
        </div>
    )
}